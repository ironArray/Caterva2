###############################################################################
# Caterva2 - On demand access to remote Blosc2 data repositories
#
# Copyright (c) 2023 ironArray SLU <contact@ironarray.io>
# https://www.blosc.org
# License: GNU Affero General Public License v3.0
# See LICENSE.txt for details about copyright and rights to use.
###############################################################################

"""Helpers for notebooks served through JupyterLite.

Kept out of ``server.py`` so they can be imported without triggering the
server module's import-time login check (which requires ``CATERVA2_SECRET``).
"""

import io

import nbformat

PYODIDE_BOOTSTRAP_INSTALL_SOURCE = """# Install blosc2 and caterva2 in Pyodide environments (automatically added)
import sys
if sys.platform == "emscripten":
    import micropip

    # Install blosc2 and caterva2 from PyPI; micropip picks the wheel matching the
    # running Pyodide ABI (e.g. cp314/pyemscripten_2026_0 on the 314.x line).
    #
    # The blosc2 >= floor is important: Pyodide bundles its own (often older) blosc2
    # in the distribution lock (e.g. 4.1.2 on 314.0.0), and micropip prefers a
    # bundled package over PyPI unless the requirement excludes it. The constraint
    # forces micropip to fetch a current release from PyPI instead of the stale
    # bundled one.
    await micropip.install(["blosc2>=4.6.0", "caterva2"])
    print("blosc2 and caterva2 installed successfully!")
"""

PYODIDE_BOOTSTRAP_IMPORT_SOURCE = """import blosc2
import caterva2
print(f"blosc2 {blosc2.__version__}, caterva2 {caterva2.__version__}")
"""


def inject_pyodide_bootstrap_cell(content: bytes) -> bytes:
    """Inject a bootstrap cell in notebooks served through JupyterLite."""
    try:
        notebook = nbformat.reads(content.decode("utf-8"), as_version=4)
    except Exception:
        return content

    # Drop any previously-injected bootstrap cell(s) and prepend fresh ones, so a
    # served notebook always carries the *current* bootstrap source. A stale cell may
    # have been baked into the saved file (e.g. persisted by save-back, or shipped in
    # the notebook); skipping when one exists would keep serving outdated install code.
    #
    # Two cells are used instead of one: JupyterLite's Pyodide kernel runs
    # loadPackagesFromImports() per cell *before* executing it, which installs the
    # old bundled version from the lockfile if the cell contains an import of a
    # package not yet loaded. By isolating the micropip.install() in its own cell
    # (no imports), we let it fetch the current release from PyPI uncontested.
    # The subsequent import cell then finds the freshly installed version.
    # See https://github.com/pyodide/pyodide-recipes/pull/605#issuecomment-4826015651
    notebook.cells = [
        cell for cell in notebook.cells if not cell.get("metadata", {}).get("caterva2_pyodide_bootstrap")
    ]

    install_cell = nbformat.v4.new_code_cell(PYODIDE_BOOTSTRAP_INSTALL_SOURCE)
    install_cell["metadata"]["caterva2_pyodide_bootstrap"] = True
    import_cell = nbformat.v4.new_code_cell(PYODIDE_BOOTSTRAP_IMPORT_SOURCE)
    import_cell["metadata"]["caterva2_pyodide_bootstrap"] = True
    notebook.cells.insert(0, install_cell)
    notebook.cells.insert(1, import_cell)

    file = io.StringIO()
    nbformat.write(notebook, file)
    return file.getvalue().encode("utf-8")
